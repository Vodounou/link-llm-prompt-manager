class CardManager {
    constructor() {
        console.log('Initialisation du gestionnaire de cartes...');
        
        // Récupérer les éléments du DOM
        this.container = document.getElementById('cardsContainer');
        this.template = document.getElementById('cardTemplate');
        this.addButton = document.getElementById('addNewCard');
        this.exportButton = document.getElementById('exportData');
        this.importButton = document.getElementById('importData');
        this.importInput = document.getElementById('importInput');
        this.themeToggle = document.getElementById('themeToggle');
        
        // Vérifier que marked est disponible
        if (typeof marked === 'undefined') {
            this.markdownAvailable = false;
            console.error('La bibliothèque marked n\'est pas chargée');
            alert('La bibliothèque marked n\'est pas chargée');
        } else {
            this.markdownAvailable = true;
            console.log('✓ Bibliothèque marked chargée avec succès');
            
            // Configurer marked avec la nouvelle API
            if (typeof marked.parse === 'function') {
                this.parseMarkdown = (text) => marked.parse(text);
            } else {
                this.parseMarkdown = (text) => marked(text);
            }
            
            // Options de sécurité
            marked.setOptions({
                sanitize: true,
                breaks: true
            });
        }

        this.cards = [];
        
        // Initialiser le thème
        this.initTheme();
        
        // Initialiser l'application
        this.init();
        console.log('✓ Gestionnaire de cartes initialisé');
    }

    initTheme() {
        console.log('Initialisation du thème...');
        // Vérifier si un thème est sauvegardé
        const savedTheme = localStorage.getItem('theme');
        
        // Vérifier les préférences système
        const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
        
        // Appliquer le thème sauvegardé ou les préférences système
        if (savedTheme) {
            console.log(`Thème sauvegardé trouvé : ${savedTheme}`);
            document.documentElement.setAttribute('data-theme', savedTheme);
        } else if (prefersDark) {
            console.log('Préférence système pour le thème sombre détectée');
            document.documentElement.setAttribute('data-theme', 'dark');
        }
        
        // Mettre à jour l'icône du bouton
        this.updateThemeIcon();
        console.log('✓ Thème initialisé');
    }

    updateThemeIcon() {
        const isDark = document.documentElement.getAttribute('data-theme') === 'dark';
        this.themeToggle.textContent = isDark ? '☀️' : '🌙';
    }

    toggleTheme() {
        console.log('Changement de thème...');
        const currentTheme = document.documentElement.getAttribute('data-theme');
        const newTheme = currentTheme === 'dark' ? 'light' : 'dark';
        
        console.log(`Passage du thème ${currentTheme || 'light'} à ${newTheme}`);
        
        document.documentElement.setAttribute('data-theme', newTheme);
        localStorage.setItem('theme', newTheme);
        
        this.updateThemeIcon();
        console.log('✓ Thème mis à jour');
    }

    init() {
        // Charger les données sauvegardées
        this.loadCards();
        
        // Ajouter les écouteurs d'événements
        this.addButton.addEventListener('click', () => this.addCard());
        this.exportButton.addEventListener('click', () => this.exportData());
        this.importButton.addEventListener('click', () => this.importInput.click());
        this.importInput.addEventListener('change', (e) => this.importData(e));
        this.themeToggle.addEventListener('click', () => this.toggleTheme());
        
        console.log('✓ Gestionnaire de cartes initialisé');
    }

    loadCards() {
        try {
            const savedCards = localStorage.getItem('cards');
            if (savedCards) {
                const cardData = JSON.parse(savedCards);
                cardData.forEach(data => this.addCard(data));
            }
        } catch (error) {
            console.error('Erreur lors du chargement des cartes:', error);
        }
    }

    addCard(data = null) {
        console.log('Ajout d\'une nouvelle carte...');
        
        // Cloner le template
        const card = this.template.content.cloneNode(true).querySelector('.card');
        
        // S'assurer que la carte est fermée par défaut
        card.classList.remove('expanded');
        card.querySelector('.btn-expand').textContent = '▼';
        
        if (data) {
            console.log('Initialisation avec les données:', data);
            card.querySelector('.card-title').textContent = data.title || 'Nouveau titre';
            card.querySelector('.card-title-edit').value = data.title || '';
            card.querySelector('.card-url').value = data.url || '';
            card.querySelector('.card-description').value = data.description || '';
            card.querySelector('.card-copytext').value = data.copytext || '';
            
            // Ne pas utiliser l'état expanded des données sauvegardées
            // pour s'assurer que toutes les cartes sont fermées au démarrage
            
            // Mettre à jour l'aperçu Markdown si disponible
            if (this.markdownAvailable && data.description) {
                card.querySelector('.markdown-preview').innerHTML = this.parseMarkdown(data.description);
            }
        }
        
        // Ajouter la carte au conteneur
        this.container.appendChild(card);
        this.cards.push(card);
        
        // Configurer les événements
        try {
            this.setupCardEvents(card);
            console.log('✓ Carte ajoutée avec succès');
        } catch (error) {
            console.error('Erreur lors de la configuration des événements:', error);
        }
        
        return card;
    }

    setupCardEvents(card) {
        console.log('Configuration des événements de la carte...');
        
        // Récupérer tous les éléments nécessaires
        const elements = {
            cardHeader: card.querySelector('.card-header'),
            cardTitle: card.querySelector('.card-title'),
            titleInput: card.querySelector('.card-title-edit'),
            urlInput: card.querySelector('.card-url'),
            description: card.querySelector('.card-description'),
            copyText: card.querySelector('.card-copytext'),
            markdownPreview: card.querySelector('.markdown-preview'),
            expandBtn: card.querySelector('.btn-expand'),
            deleteBtn: card.querySelector('.btn-delete'),
            saveButtons: card.querySelectorAll('.btn-save'),
            openUrlBtn: card.querySelector('.btn-link'),
            copyBtn: card.querySelector('.btn-copy'),
            copyOnlyBtn: card.querySelector('.btn-copy-only')
        };
        
        // Vérifier que tous les éléments sont présents
        for (const [key, element] of Object.entries(elements)) {
            if (!element && key !== 'saveButtons') {  // saveButtons peut être vide
                throw new Error(`Élément manquant: ${key}`);
            }
        }

        const toggleExpand = () => {
            const wasExpanded = card.classList.contains('expanded');
            
            // Fermer ou ouvrir toutes les cartes
            this.cards.forEach(c => {
                if (wasExpanded) {
                    c.classList.remove('expanded');
                    c.querySelector('.btn-expand').textContent = '▼';
                } else {
                    c.classList.add('expanded');
                    c.querySelector('.btn-expand').textContent = '▲';
                }
            });
        };

        // Fonction pour ouvrir les URLs
        const openUrls = () => {
            console.log('Ouverture des URLs...');
            const urls = elements.urlInput.value.trim().split('\n');
            let urlsOuvertes = false;
            urls.forEach(url => {
                if (url.trim()) {
                    window.open(url.trim(), '_blank');
                    urlsOuvertes = true;
                }
            });
            return urlsOuvertes;
        };

        // Fonction pour copier le texte
        const copyTextToClipboard = () => {
            console.log('Copie du texte...');
            const textToCopy = elements.copyText.value.trim();
            if (textToCopy) {
                navigator.clipboard.writeText(textToCopy)
                    .then(() => {
                        console.log('✓ Texte copié avec succès');
                        alert('Texte copié !');
                    })
                    .catch(err => {
                        console.error('Erreur lors de la copie:', err);
                        alert('Erreur lors de la copie : ' + err.message);
                    });
                return true;
            }
            return false;
        };

        // Gestion du clic sur le titre
        elements.cardTitle.addEventListener('click', (e) => {
            e.stopPropagation();
            console.log('Clic sur le titre...');
            
            const textCopied = copyTextToClipboard();
            const urlsOpened = openUrls();
            
            if (!textCopied && !urlsOpened) {
                console.log('Aucune action possible : pas de texte à copier ni d\'URLs à ouvrir');
            }
        });

        elements.expandBtn.addEventListener('click', (e) => {
            e.stopPropagation();
            toggleExpand();
        });

        elements.cardHeader.addEventListener('click', (e) => {
            if (e.target === elements.cardHeader) {
                toggleExpand();
            }
        });

        elements.openUrlBtn.addEventListener('click', openUrls);
        elements.copyBtn?.addEventListener('click', copyTextToClipboard);
        elements.copyOnlyBtn.addEventListener('click', copyTextToClipboard);

        if (this.markdownAvailable) {
            elements.description.addEventListener('input', () => {
                elements.markdownPreview.innerHTML = this.parseMarkdown(elements.description.value);
            });
        }

        elements.deleteBtn.addEventListener('click', () => {
            if (confirm('Êtes-vous sûr de vouloir supprimer cette carte ?')) {
                card.remove();
                this.cards = this.cards.filter(c => c !== card);
                this.saveAndExport();
            }
        });

        // Gérer tous les boutons de sauvegarde
        elements.saveButtons.forEach(saveBtn => {
            saveBtn.addEventListener('click', () => {
                console.log('Sauvegarde de la carte...');
                this.saveAndExport();
            });
        });

        // Mettre à jour le titre affiché quand l'input change
        elements.titleInput.addEventListener('input', () => {
            elements.cardTitle.textContent = elements.titleInput.value || 'Nouveau titre';
        });
        
        console.log('✓ Événements configurés avec succès');
    }

    saveAndExport() {
        try {
            const cardData = this.cards.map(card => ({
                title: card.querySelector('.card-title-edit').value,
                url: card.querySelector('.card-url').value,
                description: card.querySelector('.card-description').value,
                copytext: card.querySelector('.card-copytext').value,
                expanded: card.classList.contains('expanded')
            }));

            // Sauvegarder dans localStorage
            localStorage.setItem('cards', JSON.stringify(cardData, null, 2));

            // Créer le fichier d'export
            const dataStr = JSON.stringify(cardData, null, 2);
            const dataBlob = new Blob([dataStr], { type: 'application/json' });
            const url = URL.createObjectURL(dataBlob);
            
            const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
            const filename = `prompts_${timestamp}.json`;
            
            const link = document.createElement('a');
            link.href = url;
            link.download = filename;
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
            URL.revokeObjectURL(url);

            alert('Sauvegarde effectuée avec succès !');
        } catch (error) {
            console.error('Erreur lors de la sauvegarde:', error);
            alert('Erreur lors de la sauvegarde : ' + error.message);
        }
    }

    exportData() {
        this.saveAndExport();
    }

    importData(event) {
        const file = event.target.files[0];
        if (!file) return;

        const reader = new FileReader();
        reader.onload = (e) => {
            try {
                const cardData = JSON.parse(e.target.result);
                this.container.innerHTML = '';
                this.cards = [];
                cardData.forEach(data => this.addCard(data));
                localStorage.setItem('cards', JSON.stringify(cardData, null, 2));
            } catch (error) {
                console.error('Erreur lors de l\'import:', error);
                alert('Erreur lors de l\'import : ' + error.message);
            }
        };
        reader.readAsText(file);
        event.target.value = '';
    }
}

// Initialiser l'application
document.addEventListener('DOMContentLoaded', () => {
    new CardManager();
});
